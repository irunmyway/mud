function 内容(文本型) end
function 列数(整数型) end
function 类型(文本型) end
function 属性(文本型) end


function 给物品(id,num) end
function 给技能(id,num) end
function 删物品(id,num) end
function 删物品集(id) end
function 给经验(exp) end
function 给铜币(money) end
function 给金币(jb) end
function 给元宝(yb) end

--任务
---@return "任务"
function 状态() end
function 任务详情() end