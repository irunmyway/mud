
窗口={}
技能={}
任务={}
窗口={}
function 属性(文本型) end
function 属性.属性(文本型) end